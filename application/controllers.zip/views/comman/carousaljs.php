<script src="<?php echo base_url('/assets/owlcarousel/vendors/jquery.min.js'); ?>"></script>
<script src="<?php echo base_url('/assets/owlcarousel/owl.carousel.js'); ?>"></script>