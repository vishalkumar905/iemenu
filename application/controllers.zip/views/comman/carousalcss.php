<!--<link href="<?php echo base_url('/assets/owlcarousel/css/docs.theme.min.css'); ?>" rel="stylesheet" />-->

<link href="<?php echo base_url('/assets/owlcarousel/assets/owl.carousel.min.css'); ?>" rel="stylesheet" />
<link href="<?php echo base_url('/assets/owlcarousel/assets/owl.theme.default.min.css'); ?>" rel="stylesheet" />